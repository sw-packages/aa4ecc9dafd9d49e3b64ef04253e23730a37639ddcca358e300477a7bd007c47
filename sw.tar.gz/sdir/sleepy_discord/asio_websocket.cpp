#include "asio_websocket.h"

namespace SleepyDiscord {
#include "standard_config.h"
}