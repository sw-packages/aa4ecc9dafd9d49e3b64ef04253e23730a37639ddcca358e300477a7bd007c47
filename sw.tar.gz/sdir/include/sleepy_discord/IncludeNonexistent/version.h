#pragma once
#define NONEXISTANT_VERSION_H
