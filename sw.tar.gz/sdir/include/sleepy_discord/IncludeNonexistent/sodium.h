#pragma once
#define NONEXISTENT_SODIUM

inline int sodium_init(void) { return -1; }
