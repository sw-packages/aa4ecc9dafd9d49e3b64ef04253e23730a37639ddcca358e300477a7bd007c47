#pragma once
#include <string>

namespace SleepyDiscord {
	struct GenericWebsocketConnection {
	};
}